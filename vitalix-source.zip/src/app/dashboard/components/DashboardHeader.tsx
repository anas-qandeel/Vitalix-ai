'use client';

import { useEffect, useState, useRef } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { supabase } from '@/lib/supabase';

const VitalixLogo = () => (
  <svg className="w-5 h-5" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6 8L14.5 25C14.8 25.6 15.6 25.6 15.9 25L20 17" stroke="white" strokeWidth="3.5" strokeLinecap="round" />
    <path d="M24 6C24 9.3 26.7 12 30 12C26.7 12 24 14.7 24 18C24 14.7 21.3 12 18 12C21.3 12 24 9.3 24 6Z" fill="#2563EB" />
  </svg>
);

// الأولوية: name (العمود الرسمي المكتوب عند الإنشاء والتعديل) ← pharmacy_name (fallback للسجلات القديمة فقط)
function resolvePharmacyName(row: { name?: string | null; pharmacy_name?: string | null } | null): string {
  const raw = row?.name || row?.pharmacy_name || '';
  if (!raw.trim()) return 'صيدليتك';
  return raw.startsWith('صيدلية') ? raw : `صيدلية ${raw}`;
}

export function usePharmacyInfo() {
  const [pharmacyName, setPharmacyName] = useState('');
  const [pharmacistName, setPharmacistName] = useState('');
  const [pharmacyStatus, setPharmacyStatus] = useState('');
  const [expiryDate, setExpiryDate] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) return;
        const { data } = await supabase
          .from('pharmacies')
          .select('name, pharmacy_name, pharmacist_name, status, expiry_date')
          .eq('id', session.user.id)
          .single();
        setPharmacyName(resolvePharmacyName(data));
        setPharmacistName(data?.pharmacist_name || '');
        setPharmacyStatus(data?.status || '');
        setExpiryDate(data?.expiry_date || null);
      } catch { /* يبقى على القيم الافتراضية */ }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const getDaysLeft = () => {
    if (!expiryDate) return 0;
    return Math.max(0, Math.ceil((new Date(expiryDate).getTime() - Date.now()) / 86400000));
  };

  return { pharmacyName, pharmacistName, pharmacyStatus, expiryDate, daysLeft: getDaysLeft(), loading };
}

const NAV_LINKS = [
  { label: 'الرئيسية', href: '/dashboard', exact: true },
  { label: 'الفحوصات', href: '/dashboard/vitals', exact: false },
  { label: 'المزمنون', href: '/dashboard/chronic', exact: false },
];

interface DashboardHeaderProps {
  breadcrumb?: string;
  onBack?: () => void;
}

export default function DashboardHeader({ breadcrumb, onBack }: DashboardHeaderProps) {
  const router = useRouter();
  const pathname = usePathname();
  const { pharmacyName, pharmacistName, pharmacyStatus, daysLeft, loading } = usePharmacyInfo();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSignOut = async () => {
    setDropdownOpen(false);
    await supabase.auth.signOut();
    router.push('/');
  };

  const initials = pharmacistName
    ? pharmacistName.trim().split(' ').map((w: string) => w[0]).slice(0, 2).join('')
    : '؟';

  const isExpiringSoon = daysLeft <= 14;

  return (
    <>
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@700;800;900&display=swap');
        body { font-family: 'IBM Plex Sans Arabic', system-ui, sans-serif; }
        .font-brand { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }

        @keyframes dropdownFade {
          from { opacity: 0; transform: scale(0.96) translateY(-4px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .animate-dropdown {
          animation: dropdownFade 0.15s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          transform-origin: top left;
        }
      `}</style>

      {/* خط علوي رفيع جداً يعطي طابع الـ SaaS الفاخر */}
      <div className="sticky top-0 z-50 h-1 bg-slate-900" />

      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-1 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-[64px] flex items-center justify-between">

          {/* ██ 1. يمين الشاشة: اللوجو + أزرار التنقل (المكان الصحيح) */}
          <div className="flex items-center gap-6 shrink-0">
            {/* اللوجو */}
            <button
              onClick={() => router.push('/dashboard')}
              className="flex items-center gap-3 cursor-pointer group"
              aria-label="الرئيسية"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform duration-200">
                <VitalixLogo />
              </div>
              <div className="hidden sm:flex flex-col text-right leading-none">
                <span className="text-[15px] font-black tracking-tight font-brand text-slate-900">
                  Vitalix<span className="text-[#2563EB]">.ai</span>
                </span>
                <span className="text-[10px] text-slate-500 font-semibold mt-1 group-hover:text-slate-700 transition-colors">
                  تابع مرضاك بذكاء
                </span>
              </div>
            </button>

            {/* فاصل بين اللوجو والقائمة */}
            {!breadcrumb && <div className="hidden md:block w-px h-6 bg-slate-200 ml-2" />}

            {/* الروابط */}
            {!breadcrumb && (
              <nav className="hidden md:flex items-center gap-1">
                {NAV_LINKS.map((link) => {
                  const isActive = link.exact
                    ? pathname === link.href
                    : pathname.startsWith(link.href);
                  return (
                    <button
                      key={link.href}
                      onClick={() => router.push(link.href)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                        isActive 
                          ? 'bg-slate-100 text-slate-900 font-bold shadow-sm' 
                          : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
                      }`}
                    >
                      {link.label}
                    </button>
                  );
                })}
              </nav>
            )}

            {/* مسار الصفحة للفرعيات (Breadcrumb) */}
            {breadcrumb && (
              <div className="flex items-center gap-3 shrink-0">
                <div className="hidden md:block w-px h-6 bg-slate-200 mx-1" />
                <button
                  onClick={onBack || (() => router.back())}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                  aria-label="رجوع"
                >
                  <svg className="w-4 h-4 rtl:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                     <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <span className="text-sm font-bold text-slate-800 truncate max-w-[200px]">{breadcrumb}</span>
              </div>
            )}
          </div>

          {/* ██ 2. يسار الشاشة: اسم الصيدلية + Avatar */}
          <div className="flex items-center gap-4 shrink-0">
            
            {/* اسم الصيدلية (تصميم Badge فاخر) */}
            {!breadcrumb && (
              <div className="hidden sm:flex items-center gap-2.5 bg-gradient-to-r from-teal-50/50 to-emerald-50/50 border border-teal-100/60 px-4 py-1.5 rounded-full shadow-[0_2px_10px_-3px_rgba(20,184,166,0.15)] cursor-default">
                <span className={`w-2 h-2 rounded-full shrink-0 ${
                  pharmacyStatus === 'active' 
                    ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' 
                    : 'bg-amber-500 animate-pulse'
                }`} />
                {loading ? (
                  <span className="inline-block w-24 h-4 bg-teal-100 rounded animate-pulse" />
                ) : (
                  <span className="text-sm font-bold text-teal-900 truncate max-w-[220px]">
                    {pharmacyName}
                  </span>
                )}
              </div>
            )}

            <div className="w-px h-6 bg-slate-200" />

            {/* Avatar + Dropdown */}
            <div ref={dropdownRef} className="relative">
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-sm font-bold text-slate-700 hover:bg-slate-50 hover:border-slate-300 transition-all shadow-sm focus:outline-none focus:ring-2 focus:ring-slate-900 focus:ring-offset-2"
                aria-label="قائمة الحساب"
              >
                {loading ? <span className="w-2 h-2 rounded-full bg-slate-300 animate-pulse" /> : initials}
              </button>

              {dropdownOpen && (
                <div className="absolute top-[calc(100%+10px)] left-0 w-64 bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden z-50 animate-dropdown">
                  {/* رأس القائمة */}
                  <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/80">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-sm font-bold text-slate-700 shrink-0 shadow-sm">
                        {initials}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-bold text-slate-900 truncate">د. {pharmacistName || 'الصيدلي المسؤول'}</p>
                        <p className="text-xs text-slate-500 truncate mt-0.5">{pharmacyName}</p>
                      </div>
                    </div>
                    
                    {/* تفاصيل حالة الاشتراك */}
                    <div className="mt-3.5">
                      <span className={`inline-flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-md border ${
                        isExpiringSoon
                          ? 'bg-amber-50 text-amber-700 border-amber-200'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${isExpiringSoon ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`} />
                        اشتراك {pharmacyStatus === 'active' ? 'نشط' : 'تجريبي'} ({daysLeft} يوم)
                      </span>
                    </div>
                  </div>

                  {/* روابط القائمة */}
                  <div className="p-1.5">
                    <button className="w-full flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-600 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors" 
                      onClick={() => { setDropdownOpen(false); router.push('/dashboard/profile'); }}>
                      <span className="text-base shrink-0">👤</span>
                      <span>الملف الشخصي</span>
                    </button>
                    <button className="w-full flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-600 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors mt-0.5" 
                      onClick={() => { setDropdownOpen(false); router.push('/dashboard/pharmacy-catalog-manager'); }}>
                      <span className="text-base shrink-0">📦</span>
                      <span>الكتالوج والمنتجات</span>
                    </button>
                  </div>

                  <div className="p-1.5 border-t border-slate-100">
                    <button
                      className="w-full flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-600 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors"
                      onClick={() => {
                        setDropdownOpen(false);
                        supabase.auth.getUser().then(({ data }) => {
                          if (data.user?.email) {
                            supabase.auth.resetPasswordForEmail(data.user.email, {
                              redirectTo: `${window.location.origin}/reset-password`,
                            }).then(() => alert('تم إرسال رابط تغيير كلمة المرور إلى بريدك الإلكتروني ✅'));
                          }
                        });
                      }}
                    >
                      <span className="text-base shrink-0">🔑</span>
                      <span>تغيير كلمة المرور</span>
                    </button>
                  </div>

                  <div className="p-1.5 border-t border-slate-100 bg-slate-50/50">
                    <button className="w-full flex items-center gap-3 px-3 py-2 text-xs font-medium text-rose-600 rounded-lg hover:bg-rose-50 hover:text-rose-700 transition-colors" 
                      onClick={handleSignOut}>
                      <span className="text-base shrink-0">🚪</span>
                      <span>تسجيل الخروج</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>
      </header>
    </>
  );
}