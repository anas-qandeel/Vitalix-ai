'use client';

import { useEffect, useState, use } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import DashboardHeader from '../../components/DashboardHeader';

interface PatientDetail {
  id: string;
  name: string;
  phone_number: string;
  gender: string;
  birth_date: string;
  height: number | null;
  created_at: string;
}

interface Visit {
  id: string;
  bp_systolic: number | null;
  bp_diastolic: number | null;
  is_dual_bp: boolean;
  sugar_value: number | null;
  sugar_test_type: string | null;
  weight: number | null;
  symptoms: string[] | null;
  ai_report_output: string | null;
  created_at: string;
}

interface PageProps {
  params: Promise<{ id: string }>;
}

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('ar-EG', { numberingSystem: 'latn' });
}
function formatTime(dateStr: string) {
  return new Date(dateStr).toLocaleTimeString('ar-EG', {
    hour: '2-digit', minute: '2-digit', hour12: true, numberingSystem: 'latn',
  });
}
function calculateAge(birthDate: string) {
  const today = new Date();
  const birth = new Date(birthDate);
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
  return age;
}

export default function PatientCardPage({ params }: PageProps) {
  const resolvedParams = use(params);
  const patientId = resolvedParams.id;
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [patient, setPatient] = useState<PatientDetail | null>(null);
  const [visits, setVisits] = useState<Visit[]>([]);
  const [heightInput, setHeightInput] = useState('');
  const [savingHeight, setSavingHeight] = useState(false);
  const [expandedVisitId, setExpandedVisitId] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patientId]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        router.push('/');
        return;
      }

      const { data: patientData, error: patientError } = await supabase
        .from('patients')
        .select('*')
        .eq('id', patientId)
        .eq('pharmacy_id', session.user.id)
        .single();

      if (patientError || !patientData) {
        throw new Error('لم يتم العثور على هذا المريض، أو أنه غير تابع لصيدليتك');
      }

      setPatient(patientData as PatientDetail);
      setHeightInput(patientData.height ? String(patientData.height) : '');

      const { data: visitsData } = await supabase
        .from('visitations')
        .select('*')
        .eq('patient_id', patientId)
        .order('created_at', { ascending: false });

      setVisits((visitsData as Visit[]) || []);
    } catch (err: any) {
      setErrorMsg(err.message || 'حدث خطأ أثناء تحميل بيانات المريض');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveHeight = async () => {
    if (!patient) return;
    setSavingHeight(true);
    try {
      const newHeight = heightInput ? Number(heightInput) : null;
      const { error } = await supabase.from('patients').update({ height: newHeight }).eq('id', patient.id);
      if (error) throw new Error('تعذر حفظ الطول');
      setPatient({ ...patient, height: newHeight });
    } catch (err: any) {
      alert(err.message || 'حدث خطأ');
    } finally {
      setSavingHeight(false);
    }
  };

  const bmiValue = (weight: number | null) => {
    if (!patient?.height || !weight) return null;
    const h = patient.height / 100;
    return (weight / (h * h)).toFixed(1);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F7F8FB] flex items-center justify-center" dir="rtl">
        <p className="text-xs font-bold text-slate-400 animate-pulse">جاري تحميل كرت المريض...</p>
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="min-h-screen bg-[#F7F8FB] flex items-center justify-center p-4" dir="rtl">
        <div className="bg-white border border-slate-200 p-6 rounded-2xl max-w-md w-full text-center space-y-3">
          <div className="text-3xl">🔍</div>
          <p className="text-sm text-rose-600 font-bold">{errorMsg}</p>
          <button onClick={() => router.push('/dashboard/vitals')} className="text-xs text-teal-600 font-semibold cursor-pointer">
            ← العودة لصفحة الفحوصات
          </button>
        </div>
      </div>
    );
  }

  const age = calculateAge(patient.birth_date);
  const lastVisit = visits[0];

  return (
    <div className="min-h-screen bg-[#F7F8FB] text-slate-800 pb-16" dir="rtl">
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@700;800;900&display=swap');
        body { font-family: 'IBM Plex Sans Arabic', system-ui, sans-serif; }
        .font-brand { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
        .tabular { font-variant-numeric: tabular-nums; }
      `}</style>

      <DashboardHeader
        breadcrumb="كرت المريض"
        onBack={() => router.push('/dashboard/vitals')}
      />

      <main className="max-w-4xl mx-auto px-6 py-7 space-y-5">
        {/* بطاقة الهوية */}
        <section className="bg-gradient-to-l from-[#0F172A] to-[#164E63] text-white p-6 rounded-3xl shadow-lg shadow-slate-900/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-2xl font-black font-brand shrink-0">
              {patient.name.trim().charAt(0) || '؟'}
            </div>
            <div>
              <h1 className="text-lg font-bold">{patient.name}</h1>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-300 mt-1">
                <span>{patient.gender === 'female' ? '👩 أنثى' : '👨 ذكر'}</span>
                <span>· {age} سنة</span>
                <span className="tabular" dir="ltr">· {patient.phone_number}</span>
                <span>· عميل منذ {formatDate(patient.created_at)}</span>
              </div>
            </div>
          </div>

          <a
            href={`https://wa.me/${patient.phone_number.replace(/[^0-9]/g, '').replace(/^0/, '962')}`}
            target="_blank"
            rel="noreferrer"
            className="px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0"
          >
            <span>💬</span><span>واتساب</span>
          </a>
        </section>

        {/* الطول + إحصاء سريع */}
        <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm space-y-2">
            <p className="text-[11px] font-bold text-slate-500">📏 الطول (يُحفظ مرة واحدة)</p>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={heightInput}
                onChange={(e) => setHeightInput(e.target.value)}
                placeholder="سم"
                className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-center font-bold tabular focus:outline-none focus:border-teal-600"
              />
              <button
                onClick={handleSaveHeight}
                disabled={savingHeight}
                className="px-3 py-1.5 bg-[#0F172A] text-white rounded-xl text-[11px] font-bold shrink-0 cursor-pointer disabled:opacity-60"
              >
                حفظ
              </button>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm">
            <p className="text-[11px] font-bold text-slate-500">📊 إجمالي الزيارات الموثَّقة</p>
            <p className="text-2xl font-black text-[#0F172A] mt-1 tabular">{visits.length}</p>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm">
            <p className="text-[11px] font-bold text-slate-500">🗓️ آخر زيارة</p>
            <p className="text-sm font-bold text-[#0F172A] mt-1.5">
              {lastVisit ? `${formatDate(lastVisit.created_at)} - ${formatTime(lastVisit.created_at)}` : 'لا توجد زيارات بعد'}
            </p>
          </div>
        </section>

        {/* السجل الطبي الكامل */}
        <section className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
          <h2 className="text-sm font-bold text-[#0F172A] border-b border-slate-100 pb-3">📜 السجل الطبي الكامل</h2>

          {visits.length === 0 ? (
            <div className="py-10 text-center text-slate-400 text-xs">لا توجد أي زيارات موثَّقة لهذا المريض بعد.</div>
          ) : (
            <div className="space-y-2.5">
              {visits.map((v, idx) => {
                const isOpen = expandedVisitId === v.id;
                return (
                  <div key={v.id} className="border border-slate-200/80 rounded-xl overflow-hidden">
                    <button
                      onClick={() => setExpandedVisitId(isOpen ? null : v.id)}
                      className="w-full flex items-center justify-between gap-3 px-4 py-3 bg-slate-50/60 hover:bg-slate-50 transition cursor-pointer text-right"
                    >
                      <div className="flex items-center gap-3 flex-wrap text-xs font-bold">
                        <span className="text-slate-400 tabular">{formatDate(v.created_at)} - {formatTime(v.created_at)}</span>
                        {idx === 0 && <span className="text-[10px] bg-teal-50 text-teal-700 px-2 py-0.5 rounded-full border border-teal-200">الأحدث</span>}
                        {v.bp_systolic && <span className="text-blue-700 tabular">💓 {v.bp_systolic}/{v.bp_diastolic}</span>}
                        {v.sugar_value && <span className="text-emerald-700 tabular">🩸 {v.sugar_value}</span>}
                        {v.weight && <span className="text-purple-700 tabular">⚖️ {v.weight}kg{bmiValue(v.weight) ? ` (BMI ${bmiValue(v.weight)})` : ''}</span>}
                      </div>
                      <span className="text-slate-400 text-xs shrink-0">{isOpen ? '▲' : '▼'}</span>
                    </button>

                    {isOpen && (
                      <div className="px-4 py-3 space-y-2 border-t border-slate-100">
                        {v.symptoms && v.symptoms.length > 0 && (
                          <p className="text-[11px] text-slate-600"><strong>الأعراض:</strong> {v.symptoms.join(' ، ')}</p>
                        )}
                        {v.ai_report_output && (
                          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60 text-[11px] text-slate-700 font-mono whitespace-pre-line leading-relaxed">
                            {v.ai_report_output}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
