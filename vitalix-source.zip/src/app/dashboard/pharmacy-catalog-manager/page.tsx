'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import DashboardHeader, { usePharmacyInfo } from '../components/DashboardHeader';

interface CatalogItem {
  id?: string;
  category: 'sugar_device' | 'sugar_strips' | 'bp_device' | 'weight_loss_med';
  brand_name: string;
  price: number;
  image_url: string;
  ai_pitch_prompt: string;
  is_active: boolean;
}

const MAX_DEVICES_LIMIT = 10;

export default function PharmacyCatalogManagerPage() {
  const router = useRouter();
  const [items, setItems] = useState<CatalogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [generatingAi, setGeneratingAi] = useState(false);
  const { pharmacyName } = usePharmacyInfo();
  const [userId, setUserId] = useState<string>('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const [form, setForm] = useState<CatalogItem>({
    category: 'sugar_device',
    brand_name: '',
    price: 15.0,
    image_url: '',
    ai_pitch_prompt: '',
    is_active: true,
  });

  useEffect(() => {
    checkAuthAndFetch();
  }, []);

  const checkAuthAndFetch = async () => {
    try {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        router.push('/');
        return;
      }

      setUserId(session.user.id);

      // جلب الكتالوج الخاص بهذه الصيدلية حصراً
      const { data } = await supabase
        .from('pharmacy_catalog')
        .select('*')
        .eq('pharmacy_id', session.user.id)
        .order('created_at', { ascending: false });

      if (data) setItems(data as CatalogItem[]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // رفع الصورة مباشرة إلى Supabase Storage (catalog-images)
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadingImage(true);
      const fileExt = file.name.split('.').pop();
      const randomString = Math.random().toString(36).substring(2);
      const fileName = `${Date.now()}-${randomString}.${fileExt}`;
      const filePath = `${userId}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('catalog-images')
        .upload(filePath, file);

      if (uploadError) {
        throw new Error('فشل رفع الصورة. تأكد من إعدادات bucket باسم (catalog-images) وتفعيله كـ Public.');
      }

      const { data: { publicUrl } } = supabase.storage
        .from('catalog-images')
        .getPublicUrl(filePath);

      setForm((prev) => ({ ...prev, image_url: publicUrl }));
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء رفع الصورة');
    } finally {
      setUploadingImage(false);
    }
  };

  // استدعاء الذكاء الاصطناعي الحقيقي لتوليد الوصف العلمي والتفاعلي عبر الـ API
  const handleGenerateAiPitch = async () => {
    const name = form.brand_name.trim();
    if (!name) {
      alert('يرجى إدخال اسم الجهاز أو المنتج أولاً');
      return;
    }
    
    setGeneratingAi(true);
    try {
      const res = await fetch('/api/generate-ai-pitch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category: form.category,
          brandName: name,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'فشل في توليد الوصف بالذكاء الاصطناعي');
      }

      setForm((prev) => ({ ...prev, ai_pitch_prompt: data.pitch }));
    } catch (err: any) {
      console.error('AI Pitch Error:', err);
      alert(err.message || 'حدث خطأ أثناء توليد الوصف بالذكاء الاصطناعي');
    } finally {
      setGeneratingAi(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (items.length >= MAX_DEVICES_LIMIT) {
      alert(`عذراً، لقد وصلت للحد الأقصى المسموح به (${MAX_DEVICES_LIMIT} منتجات). يرجى حذف عنصر قديم أولاً.`);
      return;
    }

    setSaving(true);
    try {
      const payload = {
        pharmacy_id: userId,
        category: form.category,
        brand_name: form.brand_name.trim(),
        price: Number(form.price),
        image_url: form.category === 'weight_loss_med' ? null : form.image_url.trim(),
        ai_pitch_prompt: form.ai_pitch_prompt,
        is_active: form.is_active,
      };

      const { error } = await supabase.from('pharmacy_catalog').insert(payload);
      if (error) throw error;

      alert('تم حفظ المنتج في كتالوج الصيدلية بنجاح!');
      setForm({
        category: 'sugar_device',
        brand_name: '',
        price: 15.0,
        image_url: '',
        ai_pitch_prompt: '',
        is_active: true,
      });
      checkAuthAndFetch();
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء الحفظ');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteItem = async (id: string, name: string) => {
    if (!window.confirm(`هل أنت متأكد من رغبتك في حذف (${name}) نهائياً من الكتالوج؟`)) return;

    setDeletingId(id);
    try {
      const { error } = await supabase.from('pharmacy_catalog').delete().eq('id', id);
      if (error) throw error;
      setItems((prev) => prev.filter((it) => it.id !== id));
    } catch (err: any) {
      alert(err.message || 'فشل عملية الحذف');
    } finally {
      setDeletingId(null);
    }
  };

  const toggleItemStatus = async (id: string, currentStatus: boolean) => {
    await supabase.from('pharmacy_catalog').update({ is_active: !currentStatus }).eq('id', id);
    checkAuthAndFetch();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center font-sans" dir="rtl">
        <p className="text-xs font-bold text-slate-400 animate-pulse">جاري تحميل كتالوج الأجهزة...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 font-sans antialiased pb-16" dir="rtl">
      
      {/* نافذة منبثقة (Lightbox Modal) لعرض الصورة بالحجم الكامل */}
      {selectedImage && (
        <div 
          onClick={() => setSelectedImage(null)}
          className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-sm cursor-pointer"
        >
          <div className="relative max-w-xl w-full bg-white p-3 rounded-2xl shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-2 px-2">
              <span className="text-xs font-bold text-slate-700">معاينة صورة المنتج بالحجم الكامل</span>
              <button 
                onClick={() => setSelectedImage(null)}
                className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg font-bold transition cursor-pointer"
              >
                إغلاق ✕
              </button>
            </div>
            <img src={selectedImage} alt="Full Preview" className="w-full max-h-[75vh] object-contain rounded-xl border border-slate-200" />
          </div>
        </div>
      )}

      <DashboardHeader
        breadcrumb="إدارة الكتالوج والتوصيات"
        onBack={() => router.push('/dashboard')}
      />

      {/* المحتوى الرئيسي للكاتالوج */}
      <main className="max-w-5xl mx-auto px-4 pt-6 space-y-6">
        <div className="space-y-6 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
                🩺 إدارة كتالوج الأجهزة والمنتجات الموصى بها
              </h2>
              <p className="text-[11px] text-slate-500 mt-1">
                أضف الأجهزة والمنتجات مع صورها وأسعارها لاقتراحها علمياً وتلقائياً للمرضى ذوي القراءات غير المستقرة.
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-center shrink-0 min-w-[150px]">
              <div className="flex justify-between items-center text-[10px] font-bold text-slate-600 mb-1">
                <span>سعة الكتالوج</span>
                <span className={items.length >= MAX_DEVICES_LIMIT ? 'text-rose-600 font-black' : 'text-blue-600 font-mono'}>
                  {items.length} / {MAX_DEVICES_LIMIT}
                </span>
              </div>
              <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all ${items.length >= MAX_DEVICES_LIMIT ? 'bg-rose-500' : 'bg-blue-600'}`}
                  style={{ width: `${(items.length / MAX_DEVICES_LIMIT) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">تصنيف الجهاز / المنتج</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value as any })}
                  className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl font-bold"
                >
                  <option value="sugar_device">🩸 جهاز فحص السكري</option>
                  <option value="sugar_strips">💉 عبوات شرائح السكري</option>
                  <option value="bp_device">💓 جهاز قياس ضغط الدم</option>
                  <option value="weight_loss_med">⚖️ منتجات إدارة الوزن والأيض</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">اسم الجهاز / الماركة / المنتج</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: Accu-Chek / Omron / Refit"
                  value={form.brand_name}
                  onChange={(e) => setForm({ ...form, brand_name: e.target.value })}
                  className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">السعر المعتمد (دينار أردني)</label>
                <input
                  type="number"
                  step="0.5"
                  required
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                  className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl font-bold font-mono"
                />
              </div>
            </div>

            {form.category !== 'weight_loss_med' && (
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">صورة المنتج (رفع من الجهاز)</label>
                <div className="flex items-center gap-3">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="w-full text-xs p-2 bg-white border border-slate-200 rounded-xl file:ml-4 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
                  />
                  {uploadingImage && <span className="text-xs text-blue-600 font-bold animate-pulse">جاري الرفع...</span>}
                </div>
                {form.image_url && (
                  <div className="mt-2 flex items-center gap-2">
                    <img 
                      src={form.image_url} 
                      alt="Preview" 
                      onClick={() => setSelectedImage(form.image_url)}
                      className="w-12 h-12 object-cover rounded-lg border border-slate-300 cursor-pointer hover:opacity-80 transition" 
                      title="انقر لتكبير الصورة"
                    />
                    <span className="text-[10px] text-emerald-600 font-bold">تم رفع الصورة بنجاح ✓ (انقر للمعاينة)</span>
                  </div>
                )}
              </div>
            )}

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-bold text-slate-700">الوصف العلمي والنص التشجيعي (مولد ذكي بالذكاء الاصطناعي)</label>
                <button
                  type="button"
                  onClick={handleGenerateAiPitch}
                  disabled={generatingAi}
                  className="text-[10px] bg-blue-50 text-blue-700 border border-blue-200 px-2.5 py-1 rounded-lg font-bold hover:bg-blue-100 transition cursor-pointer flex items-center gap-1"
                >
                  {generatingAi ? (
                    <span className="animate-pulse">✨ جاري التوليد بالذكاء الاصطناعي...</span>
                  ) : (
                    <span>✨ توليد الوصف العلمي بالذكاء الاصطناعي</span>
                  )}
                </button>
              </div>
              <textarea
                rows={3}
                required
                value={form.ai_pitch_prompt}
                onChange={(e) => setForm({ ...form, ai_pitch_prompt: e.target.value })}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl leading-relaxed"
                placeholder="سيظهر هذا الوصف العلمي والمقترح للمريض بناءً على قراءاته..."
              />
            </div>

            <button
              type="submit"
              disabled={saving || items.length >= MAX_DEVICES_LIMIT}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition shadow-sm ${
                items.length >= MAX_DEVICES_LIMIT
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white cursor-pointer active:scale-95'
              }`}
            >
              {saving ? 'جاري الحفظ...' : items.length >= MAX_DEVICES_LIMIT ? 'وصلت للحد الأقصى (10 منتجات)' : '➕ حفظ المنتج في الكتالوج'}
            </button>
          </form>

          <div className="space-y-3 pt-2">
            <h3 className="text-xs font-bold text-slate-800">المنتجات والأجهزة المتاحة حالياً ({items.length}):</h3>
            
            {items.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs bg-slate-50 border border-dashed border-slate-200 rounded-xl">
                لم يتم إضافة منتجات لكتالوج الصيدلية حتى الآن.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {items.map((it) => (
                  <div key={it.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-start gap-3 justify-between shadow-sm">
                    <div className="flex items-start gap-3">
                      {it.image_url ? (
                        <img 
                          src={it.image_url} 
                          alt={it.brand_name} 
                          onClick={() => setSelectedImage(it.image_url)}
                          className="w-14 h-14 object-cover rounded-xl border border-slate-200 shrink-0 cursor-pointer hover:opacity-80 transition shadow-sm" 
                          title="انقر لعرض الصورة بالحجم الكامل"
                        />
                      ) : (
                        <div className="w-14 h-14 bg-purple-100 text-purple-700 font-bold rounded-xl flex items-center justify-center text-xs shrink-0">
                          ⚖️ وزن
                        </div>
                      )}
                      <div className="space-y-1">
                        <span className="font-bold text-xs text-slate-900 block">{it.brand_name}</span>
                        <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 inline-block">
                          {it.price} JOD
                        </span>
                        <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed">{it.ai_pitch_prompt}</p>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => it.id && toggleItemStatus(it.id, it.is_active)}
                        className={`text-[9px] px-2 py-0.5 rounded-md font-bold border transition cursor-pointer ${
                          it.is_active ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-200 text-slate-600 border-slate-300'
                        }`}
                      >
                        {it.is_active ? 'مفعل' : 'معطل'}
                      </button>

                      <button
                        type="button"
                        disabled={deletingId === it.id}
                        onClick={() => it.id && handleDeleteItem(it.id, it.brand_name)}
                        className="text-[10px] bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 px-2 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer"
                      >
                        <span>🗑️</span>
                        <span>{deletingId === it.id ? 'حذف...' : 'حذف'}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}