'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import DashboardHeader, { usePharmacyInfo } from '../components/DashboardHeader';

interface Patient {
  id: string;
  name: string;
  phone_number: string;
  gender: string;
  birth_date: string;
  height?: number | null;
  diagnosed_conditions?: string[] | null;
}

interface VisitationRecord {
  id: string;
  pharmacy_id: string;
  patient_id: string;
  bp_systolic: number | null;
  bp_diastolic: number | null;
  sugar_value: number | null;
  sugar_test_type: string | null;
  weight: number | null;
  symptoms: string[] | null;
  had_stimulants: boolean;
  recent_exertion: boolean;
  recent_heavy_meal: boolean;
  is_stressed: boolean;
  took_medication: boolean;
  ai_report_output: string | null;
  created_at: string;
}

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('ar-EG', { numberingSystem: 'latn' });
}
function formatTime(dateStr: string) {
  return new Date(dateStr).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', hour12: true, numberingSystem: 'latn' });
}
function normalizePhone(phone: string): string {
  let cleaned = phone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('00962')) cleaned = '0' + cleaned.substring(5);
  else if (cleaned.startsWith('962') && cleaned.length > 10) cleaned = '0' + cleaned.substring(3);
  return cleaned;
}

// ═══════════════════════════════════════════════════════
// ICONS
// ═══════════════════════════════════════════════════════
function IconPhone({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-2.896-1.596-5.265-3.965-6.861-6.861l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
    </svg>
  );
}

// ═══════════════════════════════════════════════════════
// COMPONENTS
// ═══════════════════════════════════════════════════════
function StepBar({ step }: { step: 1 | 2 }) {
  const steps = [
    { num: 1, label: 'بيانات المريض' },
    { num: 2, label: 'الفحص والتقرير' },
  ];
  return (
    <div className="flex items-center justify-center max-w-sm mx-auto mb-8">
      {steps.map((s, idx) => {
        const done = step > s.num;
        const active = step === s.num;
        return (
          <div key={s.num} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center gap-2 relative z-10">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-black transition-all duration-300 border-2 ${
                done ? 'bg-teal-600 border-teal-600 text-white shadow-md shadow-teal-200' :
                active ? 'bg-white border-teal-600 text-teal-600 shadow-md shadow-teal-100' :
                'bg-slate-50 border-slate-200 text-slate-400'
              }`}>
                {done ? (
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                ) : s.num}
              </div>
              <span className={`text-[11px] font-bold whitespace-nowrap absolute -bottom-5 ${active ? 'text-teal-700' : done ? 'text-teal-600' : 'text-slate-400'}`}>
                {s.label}
              </span>
            </div>
            {idx < steps.length - 1 && (
              <div className={`flex-1 h-1 mx-2 rounded-full transition-all duration-500 ${done ? 'bg-teal-500' : 'bg-slate-200'}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

function VitalRing({ status }: { status: { ring: string; fill: number; icon: string; label: string } }) {
  const circumference = 2 * Math.PI * 26;
  const offset = circumference * (1 - status.fill);
  return (
    <div className="relative w-12 h-12 shrink-0">
      <svg className="w-12 h-12 -rotate-90" viewBox="0 0 60 60">
        <circle cx="30" cy="30" r="26" fill="none" stroke="#F1F5F9" strokeWidth="5" />
        <circle cx="30" cy="30" r="26" fill="none" stroke={status.ring} strokeWidth="5"
          strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.6s ease, stroke 0.6s ease' }} />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-base">{status.icon}</div>
    </div>
  );
}

export default function VitalsPage() {
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [searchingPatient, setSearchingPatient] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [step, setStep] = useState<1 | 2>(1);

  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [latestGeneratedReport, setLatestGeneratedReport] = useState<string | null>(null);
  const [latestVisitId, setLatestVisitId] = useState<string | null>(null);
  const { pharmacyName } = usePharmacyInfo();

  const [activeTests, setActiveTests] = useState({ bp: false, sugar: false, weight: false });
  const [isDualBp, setIsDualBp] = useState(true);
  const [currentPatient, setCurrentPatient] = useState<Patient | null>(null);
  const [patientHistory, setPatientHistory] = useState<VisitationRecord[]>([]);

  const [formData, setFormData] = useState({
    phone_number: '',
    name: '',
    gender: 'male',
    birth_date: '1985-01-01',
    patient_height: '175',
    bp_systolic_1: '' as any, bp_diastolic_1: '' as any,
    bp_systolic_2: '' as any, bp_diastolic_2: '' as any,
    sugar_value: '' as any,
    sugar_test_type: '',
    weight: '' as any,
    had_stimulants: false,
    recent_exertion: false,
    recent_heavy_meal: false,
    is_stressed: false,
    took_medication: false,
    selectedSymptoms: [] as string[],
    newPatientConditions: [] as string[],
  });

  const router = useRouter();
  const bpSymptomsList = ['صداع', 'دوخة', 'زغللة عين', 'طنين أذن', 'ألم بالصدر', 'ضيق تنفس'];
  const sugarSymptomsList = ['عطش شديد', 'تبول متكرر', 'جفاف فم', 'خدران أطراف', 'تعرق بارد', 'جوع مفاجئ'];

  const toggleDiagnosis = async (condition: 'hypertension' | 'diabetes') => {
    if (!currentPatient) return;
    const current = currentPatient.diagnosed_conditions || [];
    const updated = current.includes(condition)
      ? current.filter((c) => c !== condition)
      : [...current, condition];

    setCurrentPatient({ ...currentPatient, diagnosed_conditions: updated });
    await supabase.from('patients').update({ diagnosed_conditions: updated }).eq('id', currentPatient.id);
  };

  useEffect(() => {
    const saved = sessionStorage.getItem('vitalix_current_patient');
    if (saved) {
      try {
        const { patient, history } = JSON.parse(saved);
        setCurrentPatient(patient);
        setPatientHistory(history || []);
        setFormData((prev) => ({
          ...prev,
          phone_number: patient.phone_number || '',
          name: patient.name || '',
          gender: patient.gender || 'male',
          birth_date: patient.birth_date || '1985-01-01',
          patient_height: patient.height ? String(patient.height) : '',
        }));
      } catch { }
      sessionStorage.removeItem('vitalix_current_patient');
    }
  }, []);

  const calculateBMI = () => {
    const h = Number(formData.patient_height) / 100;
    const w = Number(formData.weight);
    return h > 0 && w > 0 ? (w / (h * h)).toFixed(1) : null;
  };

  const getOverallStatus = () => {
    let level: 'normal' | 'medium' | 'high' = 'normal';
    if (activeTests.bp) {
      const sys = isDualBp ? Math.round((Number(formData.bp_systolic_1) + Number(formData.bp_systolic_2)) / 2) : Number(formData.bp_systolic_1);
      const dia = isDualBp ? Math.round((Number(formData.bp_diastolic_1) + Number(formData.bp_diastolic_2)) / 2) : Number(formData.bp_diastolic_1);
      if (sys >= 180 || dia >= 120 || sys < 90 || dia < 60) level = 'high';
      else if (sys >= 140 || dia >= 90) level = 'medium';
    }
    if (activeTests.sugar) {
      const sugar = Number(formData.sugar_value);
      if (sugar >= 300 || sugar < 70) level = 'high';
      else if (sugar >= 180 && level !== 'high') level = 'medium';
    }
    if (level === 'high') return { label: 'يستدعي انتباهاً', icon: '🔴', ring: '#E11D48', fill: 0.92 };
    if (level === 'medium') return { label: 'يحتاج متابعة', icon: '🟡', ring: '#F59E0B', fill: 0.58 };
    return { label: 'ضمن الطبيعي', icon: '🟢', ring: '#0D9488', fill: 0.22 };
  };

  const handlePhoneSearch = async (phone: string) => {
    setFormData((prev) => ({ ...prev, phone_number: phone }));
    setErrorMsg('');
    if (phone.length < 8) {
      setCurrentPatient(null);
      setPatientHistory([]);
      setFormData((prev) => ({ ...prev, phone_number: phone, name: '', birth_date: '', patient_height: '', gender: 'male' }));
      return;
    }
    setSearchingPatient(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;
      const { data: found } = await supabase.from('patients').select('*')
        .eq('pharmacy_id', session.user.id).eq('phone_number', normalizePhone(phone));
      if (found && found.length > 0) {
        const p = found[0] as Patient;
        setCurrentPatient(p);
        setFormData((prev) => ({ ...prev, name: p.name || '', gender: p.gender || 'male', birth_date: p.birth_date || '', patient_height: p.height ? String(p.height) : '' }));
        const { data: history } = await supabase.from('visitations').select('*').eq('patient_id', p.id).order('created_at', { ascending: false });
        if (history) setPatientHistory(history as VisitationRecord[]);
      } else {
        setCurrentPatient(null);
        setPatientHistory([]);
        setFormData((prev) => ({ ...prev, name: '', birth_date: '', patient_height: '', gender: 'male' }));
      }
    } catch (err) { console.error(err); }
    finally { setSearchingPatient(false); }
  };

  const toggleSymptom = (symptom: string) => {
    setFormData((prev) => ({
      ...prev,
      selectedSymptoms: prev.selectedSymptoms.includes(symptom)
        ? prev.selectedSymptoms.filter((s) => s !== symptom)
        : [...prev.selectedSymptoms, symptom],
    }));
  };

  const buildClientFallbackReport = (visit: any, patientName?: string, historyArr?: any[]) => {
    const bmi = calculateBMI();
    const sys = visit.bp_systolic, dia = visit.bp_diastolic, sug = visit.sugar_value;
    const symptoms: string[] = visit.symptoms || [];
    const recentVisits = Array.isArray(historyArr) ? historyArr.slice(0, 3) : [];
    const lastVisit = recentVisits[0] || null;
    const isBpAbnormal = (s: number, d: number) => s >= 140 || d >= 90 || s < 90 || d < 60;
    const isSugarAbnormal = (v: number) => v >= 180 || v < 70;
    const parts: string[] = [];
    if (sys && dia) {
      if (sys >= 180 || dia >= 120 || sys < 90 || dia < 60) parts.push(`ضغط الدم (${sys}/${dia}) خارج النطاق الطبيعي، يُفضّل مراجعة الطبيب إن استمر.`);
      else if (sys >= 140 || dia >= 90) parts.push(`ضغط الدم (${sys}/${dia}) أعلى قليلاً من الطبيعي، يُنصح بالمتابعة.`);
      else parts.push(`ضغط الدم (${sys}/${dia}) ضمن الطبيعي.`);
      const bpRecurring = isBpAbnormal(sys, dia) && recentVisits.some((v) => v.bp_systolic && v.bp_diastolic && isBpAbnormal(v.bp_systolic, v.bp_diastolic));
      if (bpRecurring) parts.push('هذا النمط تكرر بأكثر من زيارة سابقة، يُفضّل عدم التأجيل.');
      else if (lastVisit?.bp_systolic && Math.abs(sys - lastVisit.bp_systolic) >= 5) parts.push(sys > lastVisit.bp_systolic ? 'أعلى من الزيارة السابقة.' : 'أقل من الزيارة السابقة.');
    }
    if (sug) {
      if (sug < 70 || sug >= 300) parts.push(`سكري الدم (${sug}) خارج النطاق الطبيعي، يُفضّل مراجعة الطبيب إن استمر.`);
      else if (sug >= 180) parts.push(`سكري الدم (${sug}) أعلى قليلاً من الطبيعي.`);
      else parts.push(`سكري الدم (${sug}) ضمن الطبيعي.`);
      const sugarRecurring = isSugarAbnormal(sug) && recentVisits.some((v) => v.sugar_value && isSugarAbnormal(v.sugar_value));
      if (sugarRecurring) parts.push('هذا النمط تكرر بأكثر من زيارة سابقة، يُفضّل عدم التأجيل.');
      else if (lastVisit?.sugar_value && Math.abs(sug - lastVisit.sugar_value) >= 15) parts.push(sug > lastVisit.sugar_value ? 'أعلى من الزيارة السابقة.' : 'أقل من الزيارة السابقة.');
    }
    if (symptoms.length > 0) parts.push(`الأعراض المذكورة (${symptoms.join('، ')}) تستدعي المراقبة.`);
    if (parts.length === 0) parts.push('تم توثيق الزيارة بنجاح ولا توجد قراءات خارج الطبيعي.');
    if (bmi) parts.push(`BMI: ${bmi}.`);
    return `مرحباً ${patientName || 'عزيزنا المريض'}، من فريق ${pharmacyName || 'صيدليتك'} 👋 ${parts.join(' ')}`;
  };

  const generateClinicalReport = async (patientObj: any, visitPayload: any, historyArr: any[]) => {
    try {
      const res = await fetch('/api/generate-ai-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patient: patientObj,
          currentVisit: visitPayload,
          history: historyArr,
          pharmacyName,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.report) return data.report;
      }
    } catch (err) { console.warn('API error, fallback:', err); }
    return buildClientFallbackReport(visitPayload, patientObj?.name, historyArr);
  };

  const createNewPatient = async (pharmacyId: string): Promise<Patient> => {
    if (!formData.name.trim() || !formData.phone_number.trim() || !formData.birth_date) throw new Error('يرجى استكمال البيانات الأساسية (الاسم، الهاتف، تاريخ الميلاد)');
    const { data: newPatient, error } = await supabase.from('patients').insert({
      pharmacy_id: pharmacyId,
      name: formData.name.trim(),
      phone_number: normalizePhone(formData.phone_number),
      gender: formData.gender,
      birth_date: formData.birth_date,
      height: formData.patient_height ? Number(formData.patient_height) : null,
      diagnosed_conditions: formData.newPatientConditions?.length ? formData.newPatientConditions : [],
    }).select().single();
    if (error || !newPatient) throw new Error('تعذر حفظ بيانات المريض الجديد');
    return newPatient as Patient;
  };

  const handleQuickAddPatientOnly = async () => {
    setSubmitting(true); setErrorMsg('');
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('يرجى إعادة تسجيل الدخول');
      const newPatient = await createNewPatient(session.user.id);
      setCurrentPatient(newPatient);
      setPatientHistory([]);
      alert(`تم تسجيل "${newPatient.name}" كمريض جديد ✅`);
    } catch (err: any) { setErrorMsg(err.message); }
    finally { setSubmitting(false); }
  };

  const handleSaveVisitation = async () => {
    if (latestVisitId) {
      setErrorMsg('تم حفظ هذه الزيارة مسبقاً. ابدأ زيارة جديدة لتسجيل فحص آخر.');
      return;
    }
    setSubmitting(true); setErrorMsg('');
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('يرجى إعادة تسجيل الدخول');
      const pharmacyId = session.user.id;
      let patientId = currentPatient?.id;
      let activePatientObj = currentPatient;
      if (!patientId) {
        const newPatient = await createNewPatient(pharmacyId);
        patientId = newPatient.id; activePatientObj = newPatient; setCurrentPatient(newPatient);
      }
      const finalSystolic = isDualBp ? Math.round((Number(formData.bp_systolic_1) + Number(formData.bp_systolic_2)) / 2) : Number(formData.bp_systolic_1);
      const finalDiastolic = isDualBp ? Math.round((Number(formData.bp_diastolic_1) + Number(formData.bp_diastolic_2)) / 2) : Number(formData.bp_diastolic_1);
      const visitPayload = {
        bp_systolic: activeTests.bp ? finalSystolic : null,
        bp_diastolic: activeTests.bp ? finalDiastolic : null,
        is_dual_bp: activeTests.bp ? isDualBp : false,
        sugar_value: activeTests.sugar ? Number(formData.sugar_value) : null,
        sugar_test_type: activeTests.sugar ? formData.sugar_test_type : null,
        weight: activeTests.weight ? Number(formData.weight) : null,
        symptoms: formData.selectedSymptoms.length > 0 ? formData.selectedSymptoms : null,
        had_stimulants: formData.had_stimulants, recent_exertion: formData.recent_exertion,
        recent_heavy_meal: formData.recent_heavy_meal, is_stressed: formData.is_stressed,
        took_medication: formData.took_medication,
      };
      const patientForReport = {
        ...(activePatientObj || { name: formData.name, gender: formData.gender, birth_date: formData.birth_date, height: formData.patient_height }),
        diagnosed_conditions: currentPatient?.diagnosed_conditions ?? formData.newPatientConditions ?? [],
      };

      const richReport = await generateClinicalReport(patientForReport, visitPayload, patientHistory);
      setLatestGeneratedReport(richReport);
      const { data: inserted, error: visitError } = await supabase.from('visitations').insert({ pharmacy_id: pharmacyId, patient_id: patientId, ...visitPayload, ai_report_output: richReport }).select().single();
      if (visitError) throw new Error('تعذر حفظ بيانات الفحص');
      if (inserted) { setLatestVisitId(inserted.id); setPatientHistory([inserted as VisitationRecord, ...patientHistory]); }
    } catch (err: any) { setErrorMsg(err.message || 'حدث خطأ، يرجى المراجعة'); }
    finally { setSubmitting(false); }
  };

  const sendWhatsApp = () => {
    if (!latestVisitId) return;
    const phone = (currentPatient?.phone_number || formData.phone_number).replace(/[^0-9]/g, '');
    const cleanPhone = phone.startsWith('0') ? '962' + phone.substring(1) : phone;
    const visitUrl = `${window.location.origin}/dashboard/vitals/view/${latestVisitId}`;
    const patientName = currentPatient?.name || formData.name;
    const msg = `مرحباً ${patientName} 👋\nتم توثيق فحوصاتك الحيوية لدى ${pharmacyName}.\n\nرابط تقريرك الطبي:\n${visitUrl}\n\n🔒 رابط آمن ومخصص لك\n\nمع تحيات فريق ${pharmacyName} 🌿`;
    window.open(`https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handlePrintPDF = () => {
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(`<html dir="rtl" lang="ar"><head><title>تقرير فحص - ${formData.name}</title><style>body{font-family:system-ui,sans-serif;padding:40px;color:#0F172A}.header{border-bottom:2px solid #0F172A;padding-bottom:15px;margin-bottom:20px;display:flex;justify-content:space-between}.title{font-size:20px;font-weight:900}.box{background:#F8FAFC;border:1px solid #E2E8F0;padding:20px;border-radius:12px;white-space:pre-line;font-size:13px;line-height:1.7}.footer{margin-top:30px;font-size:11px;color:#64748B;text-align:center;border-top:1px solid #E2E8F0;padding-top:10px}</style></head><body><div class="header"><div class="title">Vitalix<span style="color:#0D9488">.ai</span></div><div>🏥 ${pharmacyName}</div></div><div class="box">${latestGeneratedReport}</div><div class="footer">صدر هذا التقرير عبر منصة Vitalix.ai لصالح (${pharmacyName})</div><script>window.onload=function(){window.print();window.close()}</script></body></html>`);
    w.document.close();
  };

  const handleNewVisit = () => {
    setStep(1 as 1 | 2);
    setCurrentPatient(null);
    setPatientHistory([]);
    setLatestGeneratedReport(null);
    setLatestVisitId(null);
    setErrorMsg('');
    setFormData({
      phone_number: '', name: '', gender: 'male', birth_date: '1985-01-01', patient_height: '',
      bp_systolic_1: '' as any, bp_diastolic_1: '' as any,
      bp_systolic_2: '' as any, bp_diastolic_2: '' as any,
      sugar_value: '' as any, sugar_test_type: '', weight: '' as any,
      had_stimulants: false, recent_exertion: false, recent_heavy_meal: false,
      is_stressed: false, took_medication: false, selectedSymptoms: [], newPatientConditions: [],
    });
    setActiveTests({ bp: false, sugar: false, weight: false });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-100/60 flex items-center justify-center" dir="rtl">
        <div className="w-8 h-8 border-2 border-teal-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const status = getOverallStatus();

  return (
    <div className="min-h-screen bg-slate-100/60 antialiased pb-12" dir="rtl">
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@700;800;900&display=swap');
        body { font-family: 'IBM Plex Sans Arabic', system-ui, sans-serif; }
        .tabular { font-variant-numeric: tabular-nums; }
        @keyframes slideIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
        .slide-in { animation: slideIn 0.3s ease both; }
        .num-input { appearance: textfield; -moz-appearance: textfield; }
        .num-input::-webkit-outer-spin-button, .num-input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
      `}</style>

      <DashboardHeader />

      {/* تقليل العرض الأقصى إلى max-w-2xl ليصبح مركزاً ومتماسكاً كنموذج (Form) */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 pt-10 pb-12">

        <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-200">
          <div>
            <h1 className="text-xl font-black text-slate-900">تسجيل فحص جديد</h1>
            <p className="text-xs text-slate-500 mt-1.5 font-medium">
              {step === 1 ? 'أدخل رقم هاتف المريض للبحث في السجل أو فتح ملف جديد' : 'أدخل قراءات الأجهزة بدقة لتوليد التقرير السريري'}
            </p>
          </div>
          {step > 1 && !latestGeneratedReport && (
            <button onClick={() => setStep((s) => (s - 1) as 1 | 2)}
              className="text-xs text-slate-600 hover:text-slate-900 bg-white border border-slate-200 hover:border-slate-300 px-4 py-2 rounded-lg font-bold transition shadow-sm flex items-center gap-1.5">
              <span>←</span><span>رجوع</span>
            </button>
          )}
        </div>

        <StepBar step={step} />

        {/* ═══════════════════════════════════════════
            الخطوة 1 — المريض
        ═══════════════════════════════════════════ */}
        {step === 1 && (
          <div className="slide-in space-y-5">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-7 space-y-6">

              {/* رقم الهاتف */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">رقم هاتف المريض</label>
                <div className="relative">
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400">
                    <IconPhone className="w-5 h-5" />
                  </div>
                  <input
                    type="text"
                    value={formData.phone_number}
                    onChange={(e) => handlePhoneSearch(e.target.value)}
                    placeholder="مثال: 0791234567"
                    autoFocus
                    className="w-full pr-12 pl-4 py-3.5 text-base font-mono tracking-wide bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition placeholder:text-slate-300"
                  />
                  {searchingPatient && (
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 border-2 border-teal-500 border-t-transparent rounded-full animate-spin" />
                  )}
                </div>
              </div>

              {/* مريض موجود — بطاقة تعريفية */}
              {currentPatient && (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-teal-50/50 border border-teal-100 rounded-xl px-5 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-white border border-teal-200 flex items-center justify-center font-bold text-teal-700 text-lg shadow-sm shrink-0">
                      {currentPatient.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">{currentPatient.name}</p>
                      <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                        {currentPatient.gender === 'female' ? 'أنثى' : 'ذكر'} ·{' '}
                        {new Date().getFullYear() - new Date(currentPatient.birth_date).getFullYear()} سنة
                        {patientHistory.length > 0 && <span className="text-teal-600 font-bold"> · {patientHistory.length} زيارة سابقة</span>}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <button onClick={() => {
                        sessionStorage.setItem('vitalix_current_patient', JSON.stringify({ patient: currentPatient, history: patientHistory }));
                        router.push(`/dashboard/patients/${currentPatient.id}`);
                      }}
                      className="text-[11px] font-bold text-slate-700 bg-white border border-slate-200 px-4 py-2 rounded-lg hover:bg-slate-50 transition shadow-sm">
                      السجل الكامل
                    </button>
                    <div className="w-8 h-8 rounded-lg bg-teal-500 text-white flex items-center justify-center text-sm shadow-sm">
                      ✓
                    </div>
                  </div>
                </div>
              )}

              {/* بطاقة التشخيص */}
              {currentPatient && (
                <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold text-slate-800">التشخيصات المزمنة المسجلة</p>
                    {!currentPatient.diagnosed_conditions?.length ? (
                      <span className="text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">⚠️ غير مسجّل</span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">✓ موثَّق</span>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { key: 'hypertension', label: 'مشخّص بالضغط', icon: '🫀', color: 'blue' },
                      { key: 'diabetes', label: 'مشخّص بالسكري', icon: '🩸', color: 'emerald' },
                    ].map(({ key, label, icon, color }) => {
                      const active = currentPatient.diagnosed_conditions?.includes(key) ?? false;
                      return (
                        <button key={key} type="button" onClick={() => toggleDiagnosis(key as 'hypertension' | 'diabetes')}
                          className={`flex items-center gap-3 px-4 py-3 rounded-xl border text-xs font-bold transition-all ${
                            active
                              ? color === 'blue' ? 'bg-blue-600 border-blue-600 text-white shadow-sm' : 'bg-emerald-600 border-emerald-600 text-white shadow-sm'
                              : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'
                          }`}>
                          <span className="text-lg">{icon}</span>
                          <span>{active ? '✓ ' : ''}{label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* آخر زيارتين */}
              {currentPatient && patientHistory.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">نظرة على آخر الزيارات</p>
                    {patientHistory.length > 2 && (
                      <button onClick={() => setIsHistoryModalOpen(true)} className="text-[10px] font-bold text-teal-600 hover:text-teal-700 hover:underline">
                        عرض الكل ({patientHistory.length}) ←
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {patientHistory.slice(0, 2).map((h) => (
                      <div key={h.id} className="bg-white border border-slate-200 rounded-xl p-3.5 text-xs shadow-sm">
                        <p className="text-slate-400 font-mono mb-2 pb-2 border-b border-slate-100">{formatDate(h.created_at)}</p>
                        <div className="space-y-1 font-semibold text-[11px]">
                          <p className="flex justify-between"><span className="text-slate-500">ضغط الدم</span> <span className="text-blue-700">{h.bp_systolic ? `${h.bp_systolic}/${h.bp_diastolic}` : '—'}</span></p>
                          <p className="flex justify-between"><span className="text-slate-500">السكري</span> <span className="text-emerald-700">{h.sugar_value || '—'}</span></p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* مريض جديد — حقول التسجيل */}
              {!currentPatient && formData.phone_number.length >= 8 && (
                <div className="space-y-5 pt-4 border-t border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-slate-900 text-white text-xs font-bold">+</span>
                    <p className="text-sm font-bold text-slate-900">تسجيل مريض جديد</p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">الاسم الكامل</label>
                      <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="اسم المريض بالكامل" className="w-full px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">الجنس</label>
                      <div className="flex gap-2">
                        {[{ v: 'male', l: 'ذكر' }, { v: 'female', l: 'أنثى' }].map((g) => (
                          <button key={g.v} type="button" onClick={() => setFormData({ ...formData, gender: g.v })}
                            className={`flex-1 py-3 rounded-xl border text-xs font-bold transition ${formData.gender === g.v ? 'bg-slate-900 border-slate-900 text-white shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-white'}`}>
                            {g.l}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">تاريخ الميلاد</label>
                      <input type="date" value={formData.birth_date} onChange={(e) => setFormData({ ...formData, birth_date: e.target.value })}
                        className="w-full px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition" />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">الطول (سم) — <span className="text-slate-400 font-medium">اختياري لحساب BMI</span></label>
                      <input type="number" value={formData.patient_height} placeholder="مثال: 175" onChange={(e) => setFormData({ ...formData, patient_height: e.target.value })}
                        className="w-full px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition num-input" />
                    </div>
                  </div>
                  
                  {/* التشخيصات المزمنة للمريض الجديد */}
                  <div className="bg-slate-50/50 border border-slate-200 rounded-xl p-4 space-y-3">
                    <p className="text-xs font-bold text-slate-800">التشخيصات السابقة <span className="font-normal text-slate-500">(اختياري)</span></p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        { key: 'hypertension', label: 'مشخّص بالضغط', icon: '🫀', color: 'blue' },
                        { key: 'diabetes', label: 'مشخّص بالسكري', icon: '🩸', color: 'emerald' },
                      ].map(({ key, label, icon, color }) => {
                        const active = formData.newPatientConditions?.includes(key) ?? false;
                        return (
                          <button key={key} type="button" onClick={() => {
                              const current = formData.newPatientConditions || [];
                              const updated = current.includes(key) ? current.filter((c) => c !== key) : [...current, key];
                              setFormData({ ...formData, newPatientConditions: updated });
                            }}
                            className={`flex items-center gap-3 px-4 py-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                              active ? (color === 'blue' ? 'bg-blue-600 border-blue-600 text-white' : 'bg-emerald-600 border-emerald-600 text-white') : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'
                            }`}>
                            <span className="text-lg">{icon}</span>
                            <span>{active ? '✓ ' : ''}{label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <button onClick={handleQuickAddPatientOnly} disabled={submitting || !formData.name.trim()}
                    className="w-full py-3 border border-slate-300 text-slate-700 bg-white hover:bg-slate-50 rounded-xl text-sm font-bold transition shadow-sm disabled:opacity-50">
                    حفظ الملف الشخصي فقط (بدون فحص)
                  </button>
                </div>
              )}

              {errorMsg && <p className="text-xs text-rose-600 font-bold bg-rose-50 border border-rose-200 p-3 rounded-xl">{errorMsg}</p>}
            </div>

            {/* الزر الرئيسي - استخدام التدرج اللوني الجميل الخاص بك */}
            <button
              onClick={() => setStep(2)}
              disabled={!formData.phone_number || (!currentPatient && !formData.name.trim())}
              className="w-full py-4 bg-gradient-to-l from-[#0F172A] to-[#0D9488] text-white rounded-2xl text-sm font-black transition shadow-lg shadow-teal-900/10 active:scale-[0.98] cursor-pointer disabled:opacity-40 disabled:from-slate-400 disabled:to-slate-500 flex items-center justify-center gap-2">
              <span>التالي — بدء الفحص</span>
              <span>←</span>
            </button>
          </div>
        )}

        {/* ═══════════════════════════════════════════
            الخطوة 2 — القراءات
        ═══════════════════════════════════════════ */}
        {step === 2 && (
          <div className="slide-in space-y-5">
            {/* شريط المريض */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                 <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-slate-600 shrink-0">
                    {(currentPatient?.name || formData.name).charAt(0)}
                  </div>
                <div>
                  <p className="text-sm font-bold text-slate-900">{currentPatient?.name || formData.name}</p>
                  <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                    {currentPatient?.gender === 'female' || formData.gender === 'female' ? 'أنثى' : 'ذكر'}
                    {currentPatient ? ` · ${new Date().getFullYear() - new Date(currentPatient.birth_date).getFullYear()} سنة` : ''}
                  </p>
                </div>
              </div>
              {(formData.bp_systolic_1 !== '' || formData.sugar_value !== '') && (
                <div className="flex items-center gap-2.5">
                  <p className="text-[11px] font-bold" style={{ color: status.ring }}>{status.label}</p>
                  <VitalRing status={status} />
                </div>
              )}
            </div>

            {/* اختيار الفحوصات */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
              <div>
                <p className="text-sm font-bold text-slate-900">ما هي الفحوصات المجراة؟</p>
                <p className="text-[11px] text-slate-500 font-medium mt-1">يمكنك تحديد خيار أو أكثر لإدخال القراءات.</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { key: 'bp', label: 'ضغط الدم', icon: '🫀', activeClass: 'bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-200/50' },
                  { key: 'sugar', label: 'سكري الدم', icon: '🩸', activeClass: 'bg-emerald-600 border-emerald-600 text-white shadow-md shadow-emerald-200/50' },
                  { key: 'weight', label: 'قياس الوزن', icon: '⚖️', activeClass: 'bg-purple-600 border-purple-600 text-white shadow-md shadow-purple-200/50' },
                ].map(({ key, label, icon, activeClass }) => {
                  const active = activeTests[key as keyof typeof activeTests];
                  return (
                    <button key={key} type="button" onClick={() => setActiveTests({ ...activeTests, [key]: !active })}
                      className={`flex flex-col items-center justify-center gap-2 py-4 rounded-xl border-2 text-xs font-bold transition-all ${active ? activeClass : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-300 hover:bg-white'}`}>
                      <span className="text-2xl">{icon}</span>
                      <span>{label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ضغط الدم */}
            {activeTests.bp && (
              <div className="bg-white rounded-2xl border border-blue-200 shadow-sm overflow-hidden">
                <div className="bg-blue-50/50 px-5 py-4 border-b border-blue-100 flex items-center justify-between">
                  <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>🫀</span> ضغط الدم <span className="text-slate-400 font-normal text-xs">(mmHg)</span>
                  </h2>
                  <button type="button" onClick={() => setIsDualBp(!isDualBp)}
                    className={`px-3 py-1.5 rounded-lg text-[10px] font-bold border transition flex items-center gap-1.5 ${isDualBp ? 'bg-white text-blue-700 border-blue-200 shadow-sm' : 'bg-transparent text-slate-500 border-slate-200 hover:bg-white'}`}>
                    {isDualBp ? <span className="w-2 h-2 rounded-full bg-blue-500"/> : <span className="w-2 h-2 rounded-full bg-slate-300"/>}
                    قياس مزدوج
                  </button>
                </div>
                <div className="p-5 sm:p-6 space-y-6">
                  {isDualBp && (
                    <div className="rounded-xl px-4 py-3 text-[11px] leading-relaxed border bg-blue-50/80 border-blue-100 text-blue-900">
                      <p className="font-bold flex items-center gap-1.5"><span className="text-blue-600">ℹ️</span> القياس المزدوج مُفعَّل للحصول على دقة سريرية أعلى.</p>
                    </div>
                  )}

                  <div className={`grid ${isDualBp ? 'grid-cols-2' : 'grid-cols-1'} gap-6`}>
                    <div className="space-y-3">
                      {isDualBp && <p className="text-[11px] font-bold text-slate-400 text-center uppercase tracking-wider">القراءة الأولى</p>}
                      <div className="grid grid-cols-2 gap-3">
                        {[{ label: 'SYS (انقباضي)', key: 'bp_systolic_1', ph: '120' }, { label: 'DIA (انبساطي)', key: 'bp_diastolic_1', ph: '80' }].map(({ label, key, ph }) => (
                          <div key={key}>
                            <label className="block text-[10px] font-bold text-slate-500 mb-1.5 text-center">{label}</label>
                            <input type="number" placeholder={ph} value={formData[key as keyof typeof formData] as any} onChange={(e) => setFormData({ ...formData, [key]: e.target.value === '' ? '' : Number(e.target.value) })}
                              className="w-full px-2 py-3 text-2xl font-black text-center bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition num-input placeholder:text-slate-300" />
                          </div>
                        ))}
                      </div>
                    </div>
                    {isDualBp && (
                      <div className="space-y-3 relative">
                        <div className="absolute top-8 bottom-0 -right-3 w-px bg-slate-100 hidden sm:block" />
                        <p className="text-[11px] font-bold text-slate-400 text-center uppercase tracking-wider">القراءة الثانية</p>
                        <div className="grid grid-cols-2 gap-3">
                          {[{ label: 'SYS (انقباضي)', key: 'bp_systolic_2', ph: '120' }, { label: 'DIA (انبساطي)', key: 'bp_diastolic_2', ph: '80' }].map(({ label, key, ph }) => (
                            <div key={key}>
                              <label className="block text-[10px] font-bold text-slate-500 mb-1.5 text-center">{label}</label>
                              <input type="number" placeholder={ph} value={formData[key as keyof typeof formData] as any} onChange={(e) => setFormData({ ...formData, [key]: e.target.value === '' ? '' : Number(e.target.value) })}
                                className="w-full px-2 py-3 text-2xl font-black text-center bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition num-input placeholder:text-slate-300" />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  {isDualBp && formData.bp_systolic_1 !== '' && formData.bp_systolic_2 !== '' && (
                    <div className="flex items-center justify-between bg-blue-600 text-white px-5 py-3 rounded-xl shadow-sm">
                      <span className="text-xs font-bold opacity-90">المتوسط المعتمد للتقرير:</span>
                      <span className="text-xl font-black tabular tracking-wide">{Math.round((Number(formData.bp_systolic_1) + Number(formData.bp_systolic_2)) / 2)} <span className="text-blue-300 mx-1">/</span> {Math.round((Number(formData.bp_diastolic_1) + Number(formData.bp_diastolic_2)) / 2)}</span>
                    </div>
                  )}

                  <div className="pt-5 border-t border-slate-100 space-y-4">
                    <div>
                      <p className="text-[11px] font-bold text-slate-500 mb-2.5">الأعراض المصاحبة <span className="font-normal">(اختياري)</span></p>
                      <div className="flex flex-wrap gap-2">
                        {bpSymptomsList.map((s) => {
                          const sel = formData.selectedSymptoms.includes(s);
                          return (
                            <button key={s} type="button" onClick={() => toggleSymptom(s)}
                              className={`px-3 py-2 rounded-lg text-xs font-bold transition border ${sel ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-white'}`}>
                              {sel ? '✓ ' : '+ '}{s}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* سكري الدم */}
            {activeTests.sugar && (
              <div className="bg-white rounded-2xl border border-emerald-200 shadow-sm overflow-hidden">
                <div className="bg-emerald-50/50 px-5 py-4 border-b border-emerald-100 flex items-center justify-between">
                  <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>🩸</span> سكري الدم <span className="text-slate-400 font-normal text-xs">(mg/dL)</span>
                  </h2>
                </div>
                <div className="p-5 sm:p-6 space-y-6">
                  <div>
                    <p className="text-[11px] font-bold text-slate-700 mb-2">وضع المريض عند القياس <span className="text-rose-500">*</span></p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {[{ v: 'fasting', l: 'صائم', desc: 'صيام +8 ساعات' }, { v: 'postprandial', l: 'بعد الأكل', desc: 'بعد الأكل بساعتين' }, { v: 'random', l: 'عشوائي', desc: 'في أي وقت آخر' }].map(({ v, l, desc }) => {
                        const sel = formData.sugar_test_type === v;
                        return (
                          <button key={v} type="button" onClick={() => setFormData({ ...formData, sugar_test_type: v })}
                            className={`flex flex-col gap-1 p-3 rounded-xl border-2 text-right transition ${sel ? 'bg-emerald-600 border-emerald-600 text-white shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-emerald-300 hover:bg-white'}`}>
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold">{l}</span>
                              <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${sel ? 'border-white' : 'border-slate-300'}`}>{sel && <div className="w-1.5 h-1.5 rounded-full bg-white" />}</div>
                            </div>
                            <span className={`text-[10px] font-medium ${sel ? 'text-emerald-100' : 'text-slate-400'}`}>{desc}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div>
                    <input type="number" placeholder="أدخل القراءة (مثال: 110)" value={formData.sugar_value} disabled={!formData.sugar_test_type}
                      onChange={(e) => setFormData({ ...formData, sugar_value: e.target.value === '' ? '' : Number(e.target.value) })}
                      className="w-full px-4 py-4 text-3xl sm:text-4xl font-black text-center bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition num-input placeholder:text-slate-300 placeholder:text-xl disabled:opacity-50" />
                  </div>
                  <div className="pt-5 border-t border-slate-100 space-y-4">
                    <div>
                      <p className="text-[11px] font-bold text-slate-500 mb-2.5">الأعراض المصاحبة <span className="font-normal">(اختياري)</span></p>
                      <div className="flex flex-wrap gap-2">
                        {sugarSymptomsList.map((s) => {
                          const sel = formData.selectedSymptoms.includes(s);
                          return (
                            <button key={s} type="button" onClick={() => toggleSymptom(s)}
                              className={`px-3 py-2 rounded-lg text-xs font-bold transition border ${sel ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-white'}`}>
                              {sel ? '✓ ' : '+ '}{s}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* الوزن */}
            {activeTests.weight && (
              <div className="bg-white rounded-2xl border border-purple-200 shadow-sm overflow-hidden">
                <div className="bg-purple-50/50 px-5 py-4 border-b border-purple-100 flex items-center justify-between">
                  <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>⚖️</span> قياس الوزن <span className="text-slate-400 font-normal text-xs">(kg)</span>
                  </h2>
                  {formData.weight !== '' && formData.patient_height && calculateBMI() && (
                    <span className="text-xs bg-purple-600 text-white font-bold px-3 py-1.5 rounded-lg shadow-sm">BMI: {calculateBMI()}</span>
                  )}
                </div>
                <div className="p-5 sm:p-6">
                  <input type="number" placeholder="أدخل الوزن (مثال: 75)" value={formData.weight}
                    onChange={(e) => setFormData({ ...formData, weight: e.target.value === '' ? '' : Number(e.target.value) })}
                    className="w-full px-4 py-4 text-3xl sm:text-4xl font-black text-center bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition num-input placeholder:text-slate-300 placeholder:text-xl" />
                </div>
              </div>
            )}

            {!activeTests.bp && !activeTests.sugar && !activeTests.weight && (
              <div className="bg-slate-100 border border-slate-200 rounded-xl px-5 py-6 text-sm text-slate-500 font-bold text-center flex flex-col items-center justify-center gap-2">
                <svg className="w-6 h-6 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                الرجاء اختيار فحص واحد على الأقل من القائمة بالأعلى
              </div>
            )}

            {errorMsg && (
              <div className="bg-rose-50 border border-rose-200 px-4 py-3 rounded-xl flex items-center gap-2 text-xs font-bold text-rose-700">
                <span>⚠️</span><span>{errorMsg}</span>
              </div>
            )}

            <button onClick={async () => { await handleSaveVisitation(); }}
              disabled={submitting || !!latestVisitId || (!activeTests.bp && !activeTests.sugar && !activeTests.weight)}
              className={`w-full py-4 text-white rounded-2xl text-sm font-black transition shadow-lg active:scale-[0.98] flex items-center justify-center gap-2 ${
                latestVisitId ? 'bg-emerald-600 cursor-not-allowed shadow-none' : 'bg-gradient-to-l from-[#0F172A] to-[#0D9488] shadow-teal-900/10 cursor-pointer disabled:opacity-40 disabled:from-slate-400 disabled:to-slate-500'
              }`}>
              {submitting ? (
                <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /><span>جاري حفظ وتحليل البيانات...</span></>
              ) : latestVisitId ? (
                <span>✓ تم الحفظ بنجاح</span>
              ) : (
                <span>توليد التقرير الطبي الذكي وحفظ الزيارة</span>
              )}
            </button>
          </div>
        )}

        {/* ═══════════════════════════════════════════
            التقرير السريري
        ═══════════════════════════════════════════ */}
        {step === 2 && latestGeneratedReport && (
          <div className="slide-in space-y-6 mt-8 pt-8 border-t border-slate-200">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2"><span>✨</span> التقرير الطبي الذكي</h3>
                <span className="text-[10px] bg-slate-900 text-white px-2.5 py-1 rounded-md font-bold uppercase tracking-wider">Vitalix AI</span>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 text-sm text-slate-700 leading-relaxed font-medium">
                {latestGeneratedReport}
              </div>
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button onClick={handlePrintPDF} className="flex-1 flex items-center justify-center gap-2 py-3.5 bg-white border border-slate-200 text-slate-700 rounded-xl text-xs font-bold transition hover:bg-slate-50 shadow-sm cursor-pointer">
                  <span>🖨️</span><span>طباعة التقرير (PDF)</span>
                </button>
                <button onClick={sendWhatsApp} className="flex-1 flex items-center justify-center gap-2 py-3.5 bg-[#25D366] hover:bg-[#20BD5A] text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer">
                  <span>💬</span><span>إرسال عبر WhatsApp</span>
                </button>
              </div>
            </div>
            <button onClick={handleNewVisit} className="w-full py-4 bg-white border-2 border-slate-200 hover:border-teal-600 hover:text-teal-600 text-slate-600 rounded-2xl text-sm font-bold transition shadow-sm active:scale-[0.98] cursor-pointer">
              + بدء فحص لمريض آخر
            </button>
          </div>
        )}

      </main>

      <footer className="max-w-2xl mx-auto px-6 py-8 text-center border-t border-slate-200/60 mt-4 flex flex-col items-center justify-center gap-2">
        <div className="text-[11px] text-slate-500 font-medium select-none" style={{ direction: 'ltr', unicodeBidi: 'bidi-override' }}>
          Made <span className="text-rose-500 text-[10px]">♥</span> in <span className="font-bold tracking-wider text-slate-700">ΛMMΛN</span>
        </div>
        <p className="text-[11px] text-slate-400 font-medium">
          Vitalix<span className="text-slate-900">.ai</span> — v1.0.0 · © {new Date().getFullYear()} جميع الحقوق محفوظة
        </p>
      </footer>

      {/* Modal الأرشيف */}
      {isHistoryModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 transition-all"
          onClick={() => setIsHistoryModalOpen(false)}>
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden shadow-2xl flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100 bg-white shrink-0">
              <div>
                <h3 className="text-base font-bold text-slate-900">سجل الزيارات الكامل</h3>
                <p className="text-[11px] text-slate-500 font-medium mt-0.5">{currentPatient?.name} — {patientHistory.length} زيارة مسجلة</p>
              </div>
              <button onClick={() => setIsHistoryModalOpen(false)} className="w-8 h-8 bg-slate-50 hover:bg-slate-100 text-slate-500 rounded-full flex items-center justify-center font-bold transition cursor-pointer">✕</button>
            </div>
            <div className="overflow-y-auto p-6 space-y-4 bg-slate-50/50 flex-1">
              {patientHistory.map((visit, idx) => (
                <div key={visit.id} className="bg-white border border-slate-200 rounded-xl p-5 space-y-3 shadow-sm">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded-md">{formatDate(visit.created_at)} — {formatTime(visit.created_at)}</span>
                    <span className="text-slate-400 font-bold text-xs">#{patientHistory.length - idx}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-3 text-xs font-bold bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <span className="text-slate-700 flex flex-col gap-1"><span className="text-[10px] text-slate-400">ضغط الدم</span> {visit.bp_systolic ? `${visit.bp_systolic}/${visit.bp_diastolic}` : '—'}</span>
                    <span className="text-slate-700 flex flex-col gap-1"><span className="text-[10px] text-slate-400">السكري</span> {visit.sugar_value || '—'}</span>
                    <span className="text-slate-700 flex flex-col gap-1"><span className="text-[10px] text-slate-400">الوزن</span> {visit.weight ? `${visit.weight} kg` : '—'}</span>
                  </div>
                  {visit.ai_report_output && (
                    <div className="pt-2">
                      <p className="text-[10px] font-bold text-slate-400 mb-1">التقرير الذكي:</p>
                      <p className="text-[11px] text-slate-600 font-medium leading-relaxed bg-white border border-slate-100 p-3 rounded-lg">{visit.ai_report_output}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}